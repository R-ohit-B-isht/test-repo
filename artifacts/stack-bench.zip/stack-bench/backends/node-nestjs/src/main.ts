import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { logger: false });
  await app.listen(process.env.PORT ?? 3004);
  console.log('READY');
}
bootstrap();
