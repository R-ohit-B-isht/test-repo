export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "fe/sveltekit/_app",
	assets: new Set([]),
	mimeTypes: {},
	_: {
		client: {start:"_app/immutable/entry/start.DPsCtXTa.js",app:"_app/immutable/entry/app.BvMgPgKH.js",imports:["_app/immutable/entry/start.DPsCtXTa.js","_app/immutable/chunks/CBqmiwxX.js","_app/immutable/chunks/C4RMYY0W.js","_app/immutable/chunks/DA3GAWiu.js","_app/immutable/entry/app.BvMgPgKH.js","_app/immutable/chunks/C4RMYY0W.js","_app/immutable/chunks/BlLJ8Lgu.js","_app/immutable/chunks/DBU8Dg9E.js","_app/immutable/chunks/DA3GAWiu.js","_app/immutable/chunks/DHXWItJL.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
