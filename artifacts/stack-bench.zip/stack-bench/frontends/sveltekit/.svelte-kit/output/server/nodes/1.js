

export const index = 1;
export const imports = ["_app/immutable/nodes/1.CCefVqEb.js","_app/immutable/chunks/DBU8Dg9E.js","_app/immutable/chunks/C4RMYY0W.js","_app/immutable/chunks/BlLJ8Lgu.js","_app/immutable/chunks/CBqmiwxX.js","_app/immutable/chunks/DA3GAWiu.js"];
export const stylesheets = [];
export const fonts = [];
