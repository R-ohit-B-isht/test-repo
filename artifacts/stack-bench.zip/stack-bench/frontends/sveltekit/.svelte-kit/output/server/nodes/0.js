

export const index = 0;
export const universal = {
  "ssr": false,
  "prerender": false
};
export const universal_id = "src/routes/+layout.js";
export const imports = ["_app/immutable/nodes/0.CUwBrYwy.js","_app/immutable/chunks/DBU8Dg9E.js","_app/immutable/chunks/C4RMYY0W.js","_app/immutable/chunks/DHXWItJL.js"];
export const stylesheets = [];
export const fonts = [];
