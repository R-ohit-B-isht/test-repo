

export const index = 2;
export const imports = ["_app/immutable/nodes/2.lh3plYx7.js","_app/immutable/chunks/DBU8Dg9E.js","_app/immutable/chunks/C4RMYY0W.js","_app/immutable/chunks/DA3GAWiu.js","_app/immutable/chunks/BlLJ8Lgu.js"];
export const stylesheets = [];
export const fonts = [];
