import { a4 as ensure_array_like, e as escape_html, a3 as derived } from "../../chunks/index.js";
const COLS = ["id", "service", "region", "status", "latency_ms", "rps", "updated_at"];
function sortRows(rows, key, dir) {
  return [...rows].sort((a, b) => (a[key] > b[key] ? 1 : a[key] < b[key] ? -1 : 0) * dir);
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let rows = [];
    let key = "id";
    let dir = 1;
    let sorted = derived(() => sortRows(rows, key, dir));
    $$renderer2.push(`<h1>sveltekit console</h1> <button id="act">Run action</button> <span id="actres"></span><ul id="feed"></ul> <table><tbody><tr><!--[-->`);
    const each_array = ensure_array_like(COLS);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let c = each_array[$$index];
      $$renderer2.push(`<th>${escape_html(c)}</th>`);
    }
    $$renderer2.push(`<!--]--></tr><!--[-->`);
    const each_array_1 = ensure_array_like(sorted());
    for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
      let r = each_array_1[$$index_2];
      $$renderer2.push(`<tr><!--[-->`);
      const each_array_2 = ensure_array_like(COLS);
      for (let $$index_1 = 0, $$length2 = each_array_2.length; $$index_1 < $$length2; $$index_1++) {
        let c = each_array_2[$$index_1];
        $$renderer2.push(`<td>${escape_html(r[c])}</td>`);
      }
      $$renderer2.push(`<!--]--></tr>`);
    }
    $$renderer2.push(`<!--]--></tbody></table>`);
  });
}
export {
  _page as default
};
